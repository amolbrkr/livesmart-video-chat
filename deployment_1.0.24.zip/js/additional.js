$(document).on('CallEnded', function (e) {
    console.log('Additional call ended');
});