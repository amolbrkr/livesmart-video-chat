
SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `users`
-- ----------------------------
ALTER TABLE `rooms`
ADD COLUMN `shortagenturl`  varchar(255) NULL AFTER `duration`,
ADD COLUMN `shortvisitorurl`  varchar(255) NULL AFTER `shortagenturl`;



