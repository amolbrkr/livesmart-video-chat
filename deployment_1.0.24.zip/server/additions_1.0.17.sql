SET FOREIGN_KEY_CHECKS=0;
ALTER TABLE `rooms`
ADD COLUMN `agent_id`  varchar(255) NULL AFTER `shortvisitorurl`;


DROP TABLE IF EXISTS `agents`;
CREATE TABLE `agents` (
  `agent_id` int(11) NOT NULL AUTO_INCREMENT,
  `tenant` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_master` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`agent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of agents
-- ----------------------------
INSERT INTO `agents` VALUES ('1', 'admin', 'first', 'last', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'admin@admin.com', '1');



ALTER TABLE `users`
CHANGE COLUMN `id` `user_id`  int(11) NOT NULL AUTO_INCREMENT FIRST ,
ADD COLUMN `name`  varchar(255) NULL AFTER `password`,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`user_id`);